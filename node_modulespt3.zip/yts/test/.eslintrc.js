module.exports = {
  env: {
    "jest/globals": true,
  },
};
