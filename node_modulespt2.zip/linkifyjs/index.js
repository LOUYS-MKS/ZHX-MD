module.exports = require('./lib/linkify');
