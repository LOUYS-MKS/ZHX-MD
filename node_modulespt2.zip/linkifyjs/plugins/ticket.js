typeof console !== 'undefined' && console && console.warn && console.warn('"linkifyjs/plugins/ticket" is deprecated in v3. Please install "linkify-plugin-ticket" instead');
require('../lib/plugins/ticket');
module.exports = () => {}; // noop for compatibility with v2
