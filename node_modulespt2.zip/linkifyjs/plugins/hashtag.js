typeof console !== 'undefined' && console && console.warn && console.warn('"linkifyjs/plugins/hashtag" is deprecated in v3. Please install "linkify-plugin-hashtag" instead');
require('../lib/plugins/hashtag');
module.exports = () => {}; // noop for compatibility with v2
