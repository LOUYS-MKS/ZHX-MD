typeof console !== 'undefined' && console && console.warn && console.warn('"linkifyjs/string" is deprecated in v3. Please install "linkify-string" instead');
module.exports = require('./lib/linkify-string');
