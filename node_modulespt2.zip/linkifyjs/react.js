throw new Error('"linkifyjs/react" is not available in v3. Please install "linkify-react"');
