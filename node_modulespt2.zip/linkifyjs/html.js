typeof console !== 'undefined' && console && console.warn && console.warn('"linkifyjs/html" is deprecated in v3. Please install "linkify-html" instead');
module.exports = require('./lib/linkify-html');
