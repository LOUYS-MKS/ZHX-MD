throw new Error('"linkifyjs/element" is not available in v3. Please install "linkify-element"');
