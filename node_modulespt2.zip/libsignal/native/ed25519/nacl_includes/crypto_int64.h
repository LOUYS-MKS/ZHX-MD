#ifndef crypto_int64_h
#define crypto_int64_h

typedef long long crypto_int64;

#endif
