const alteradores = (prefix) => {

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return`

╭───────────────
╎
┝  ⎙ Audios  - Modificar
╎
╰──────────
╎
╎⩺ ${prefix}rapido (marca)
╎⩺ ${prefix}lento (marca)
╎⩺ ${prefix}Grave (marca)
╎⩺ ${prefix}Grave2 (marca)
╎⩺ ${prefix}Esquilo (marca)
╎⩺ ${prefix}Estourar (marca)
╎⩺ ${prefix}Vozmenino (marca)
╎
╰─────────────╯
`
}

exports.alteradores = alteradores